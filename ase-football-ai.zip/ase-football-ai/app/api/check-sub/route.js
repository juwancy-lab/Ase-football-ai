import { cookies } from "next/headers";

export async function GET() {
  try {
    const cookieStore = await cookies();
    const sub = cookieStore.get("ase_sub");

    if (!sub) return Response.json({ active: false });

    const data = JSON.parse(sub.value);

    if (Date.now() > data.expiresAt) {
      // Expired — delete cookie
      cookieStore.delete("ase_sub");
      return Response.json({ active: false, expired: true });
    }

    return Response.json({
      active: true,
      plan: data.plan,
      email: data.email,
      expiresAt: data.expiresAt,
    });
  } catch (e) {
    return Response.json({ active: false });
  }
}
