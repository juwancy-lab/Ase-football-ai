const GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";

const CAT_PROMPTS = {
  multigoals: `MULTIGOALS MARKETS: Match Multigoals (1-2, 1-3, 1-4, 2-3, 2-4, 3-5 ranges), Home Team Multigoals (1-2, 1-3, No goal), Away Team Multigoals (1-2, 1-3, No goal), 1st Half Multigoals (No goal, 1-2, 1-3), Multiscores (grouped correct scores). Give 8-12 predictions.`,
  main: `MAIN MARKETS: 1X2, Double Chance, Draw No Bet, Asian Handicap, GG/NG, Correct Score, HT/FT, Winning Margin, Odd/Even, 1st Goal, Last Goal. Give 8-12 predictions.`,
  goals: `GOALS MARKETS: Over/Under 0.5/1.5/2.5/3.5, BTTS, Home/Away Clean Sheet, Home/Away Goals O/U 0.5/1.5, Goal Bounds, Exact Goals. Give 8-12 predictions.`,
  half: `HALF MARKETS: 1st Half 1X2, 1H O/U 0.5, 1H Double Chance, 1H GG/NG, 1H Correct Score, 2nd Half 1X2, 2H O/U 0.5, 2H GG/NG, Home/Away Score Both Halves. Give 8-12 predictions.`,
  bookings: `BOOKINGS: Cards O/U 3.5/4.5, Bookings 1X2, 1st Booking, Booking Points O/U, Home/Away Cards O/U 1.5. Give 6-8 predictions.`,
  corners: `CORNERS: Corners O/U 8.5/9.5/10.5, Corners 1X2, 1st Corner, Corner Handicap, Home/Away Corners O/U 3.5, 1H Corners O/U 4.5. Give 6-8 predictions.`,
  combo: `COMBO: 1X2 & O/U 2.5, 1X2 & GG/NG, DC & O/U 2.5, DC & GG/NG, Win to Nil, O/U & GG/NG, Win From Behind. Give 6-8 predictions.`,
  teams: `TEAMS: Home/Away Shots O/U 4.5, Home/Away SOT O/U 2.5, Home/Away Fouls O/U 10.5, Home/Away Offsides O/U 1.5. Give 6-8 predictions.`,
  match: `MATCH: Total Cards O/U, Shots 1X2, SOT 1X2, Penalty Scored Yes/No, Goal by Sub Yes/No. Give 4-6 predictions.`,
};

const SYSTEM = `You are the prediction engine for Ase Football AI. You analyze football matches using 17 weighted factors:

1. Recent Form (25%) - Last 5 matches, goals scored/conceded
2. Home/Away Advantage (15%) - Historical home win rates
3. Head-to-Head Record (10%) - Last 5 meetings
4. Goal Statistics (15%) - Average goals, xG
5. League Position Gap (10%) - Table standings difference
6. Key Player Availability (10%) - Injuries, suspensions
7. Fixture Congestion (8%) - Rest days
8. Motivation/Stakes (7%) - Title race, relegation
9. Weather (3%)
10. Referee Tendency (3%)
11. Manager Tactics (5%)
12. Transfer Impact (3%)
13. Derby Factor (2%)
14. Travel Distance (2%)
15. Scoring Timing (3%)
16. Clean Sheet Probability (3%)
17. xG Trend (5%)

CRITICAL RULES:
- Use Google Search to find REAL current data about both teams
- Be HONEST with confidence levels. Most should be 40-75%. Only truly obvious picks get 80+.
- Give SPECIFIC reasoning referencing actual stats, form, and data you found
- Use actual team names throughout

RESPOND WITH ONLY A JSON OBJECT. No markdown, no backticks, no extra text before or after the JSON.

{
  "category_predictions": [
    {
      "market": "Market Name",
      "pick": "Your Selection",
      "confidence": 72,
      "rating": "GOOD",
      "odds_hint": "~1.65",
      "reasoning": "2-3 sentences with real stats and data supporting this pick.",
      "key_factors": ["Factor 1", "Factor 2"]
    }
  ],
  "top_5_overall": [
    {
      "rank": 1,
      "market": "Best Market",
      "pick": "Selection",
      "confidence": 88,
      "rating": "STRONG",
      "odds_hint": "~1.20",
      "category": "Goals",
      "reasoning": "Why this is the best pick for this entire match.",
      "key_factors": ["Factor 1", "Factor 2"]
    }
  ]
}

top_5_overall = the 5 BEST predictions across ALL market categories (not just the requested one), ranked 1 to 5.
Rating rules: 80+ = "STRONG", 65-79 = "GOOD", 50-64 = "FAIR", below 50 = "RISKY"
ONLY OUTPUT THE JSON OBJECT.`;

export async function POST(req) {
  try {
    const { home, away, league, category } = await req.json();
    if (!home || !away || !league || !category)
      return Response.json({ error: "Missing fields" }, { status: 400 });

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return Response.json({ error: "API key not configured" }, { status: 500 });

    const catPrompt = CAT_PROMPTS[category] || CAT_PROMPTS.main;

    const res = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        system_instruction: {
          parts: [{ text: SYSTEM }]
        },
        contents: [{
          role: "user",
          parts: [{
            text: `Analyze this football match:

Match: ${home} (HOME) vs ${away} (AWAY)
League: ${league}

Search for real data:
- ${home} last 5 match results and current form
- ${away} last 5 match results and current form
- ${home} vs ${away} head to head recent results
- ${league} current standings
- ${home} team news and injuries
- ${away} team news and injuries

REQUESTED CATEGORY TO PREDICT:
${catPrompt}

ALSO: Generate top_5_overall — the 5 absolute BEST predictions across ALL market categories (Main, Goals, Multigoals, Half, Corners, Bookings, Combo, Teams, Match). Ranked 1 to 5.

Apply all 17 prediction factors using the real data you found. Output ONLY the JSON object.`
          }]
        }],
        tools: [{ google_search: {} }],
        generationConfig: {
          temperature: 0.4,
          maxOutputTokens: 8000,
        }
      }),
    });

    const json = await res.json();

    if (json.error) {
      console.error("Gemini error:", json.error);
      return Response.json({ error: json.error.message }, { status: 500 });
    }

    let raw = "";
    const candidates = json.candidates || [];
    for (const c of candidates) {
      for (const part of (c.content?.parts || [])) {
        if (part.text) raw += part.text;
      }
    }

    raw = raw.trim().replace(/```json/g, "").replace(/```/g, "").trim();

    const objStart = raw.indexOf("{");
    const objEnd = raw.lastIndexOf("}");
    const arrStart = raw.indexOf("[");
    const arrEnd = raw.lastIndexOf("]");

    let data;
    if (objStart !== -1 && (arrStart === -1 || objStart < arrStart)) {
      data = JSON.parse(raw.substring(objStart, objEnd + 1));
    } else if (arrStart !== -1) {
      data = { category_predictions: JSON.parse(raw.substring(arrStart, arrEnd + 1)), top_5_overall: [] };
    } else {
      return Response.json({ error: "Could not parse AI response. Try again." }, { status: 500 });
    }

    return Response.json(data);
  } catch (e) {
    console.error(e);
    return Response.json({ error: e.message }, { status: 500 });
  }
}
