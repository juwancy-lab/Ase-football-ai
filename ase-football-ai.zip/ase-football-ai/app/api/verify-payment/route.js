import { cookies } from "next/headers";

export async function POST(req) {
  try {
    const { reference, plan } = await req.json();
    if (!reference || !plan) return Response.json({ error: "Missing reference or plan" }, { status: 400 });

    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    if (!secretKey) return Response.json({ error: "Payment not configured" }, { status: 500 });

    // Verify payment with Paystack
    const res = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
      headers: { Authorization: `Bearer ${secretKey}` },
    });

    const data = await res.json();

    if (!data.status || data.data.status !== "success") {
      return Response.json({ error: "Payment not verified" }, { status: 400 });
    }

    // Check amount matches plan
    const amounts = { daily: 200000, weekly: 1000000, monthly: 2500000 }; // in kobo
    const expectedAmount = amounts[plan];

    if (data.data.amount < expectedAmount) {
      return Response.json({ error: "Amount mismatch" }, { status: 400 });
    }

    // Calculate expiry
    const durations = { daily: 1, weekly: 7, monthly: 30 };
    const days = durations[plan] || 1;
    const expiresAt = Date.now() + days * 24 * 60 * 60 * 1000;

    // Set subscription cookie
    const cookieStore = await cookies();
    cookieStore.set("ase_sub", JSON.stringify({
      plan,
      reference,
      email: data.data.customer.email,
      expiresAt,
    }), {
      httpOnly: true,
      secure: true,
      sameSite: "strict",
      maxAge: days * 24 * 60 * 60,
      path: "/",
    });

    return Response.json({
      success: true,
      plan,
      expiresAt,
      email: data.data.customer.email,
    });
  } catch (e) {
    console.error(e);
    return Response.json({ error: e.message }, { status: 500 });
  }
}
